module.exports = {
  mode: '',
  purge: ['./public/**/*.html', './src/**/*.{js,jsx,ts,tsx,vue}'],
  variants: {},
  // specify other options here
};
